import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ProfissionalApi {
    id: string;
    nome: string;
    email: string;
    cpf: string;
    telefone: string;
    categoria: string;
    formacaoAcademica: string;
    numeroRegistro: string;
    anoConclusao: number | null;
    atendeOnline: boolean;
    ativo: boolean;
}

export interface DisponibilidadeApi {
    id: string;
    diaSemana: string;
    horaInicio: string;
    horaFim: string;
    ativo: boolean;
}

@Injectable({
    providedIn: 'root',
})
export class ProfissionaisApiService {
    private readonly http = inject(HttpClient);
    private readonly api = '/api/profissionais';

    listarTodos(): Observable<ProfissionalApi[]> {
        return this.http.get<ProfissionalApi[]>(this.api);
    }

    buscarPorId(id: string): Observable<ProfissionalApi> {
        return this.http.get<ProfissionalApi>(`${this.api}/${id}`);
    }

    listarDisponibilidades(
        profissionalId: string
    ): Observable<DisponibilidadeApi[]> {
        return this.http.get<DisponibilidadeApi[]>(
            `${this.api}/${profissionalId}/disponibilidades`
        );
    }
}