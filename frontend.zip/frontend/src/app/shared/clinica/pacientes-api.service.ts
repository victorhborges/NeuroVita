import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface PacienteApi {
    id: string;
    nome: string;
    dataNascimento: string;
    email: string;
    cpf: string;
    telefone: string;
    responsaveis: {
        responsavelId: string;
        grauParentesco: string;
    }[];
    possuiPlanoSaude: boolean;
    planoSaude: string;
    numeroCarteirinha: string;
    validadePlano: string | null;
}

@Injectable({
    providedIn: 'root',
})
export class PacientesApiService {
    private readonly http = inject(HttpClient);
    private readonly api = '/api/pacientes';

    listarTodos(): Observable<PacienteApi[]> {
        return this.http.get<PacienteApi[]>(this.api);
    }

    buscarPorId(id: string): Observable<PacienteApi> {
        return this.http.get<PacienteApi>(`${this.api}/${id}`);
    }
}