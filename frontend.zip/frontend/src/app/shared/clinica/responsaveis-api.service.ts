import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ResponsavelApi {
    id: string;
    nome: string;
    cpf: string;
    email: string;
    telefone: string;
}

@Injectable({
    providedIn: 'root',
})
export class ResponsaveisApiService {
    private readonly http = inject(HttpClient);
    private readonly api = '/api/responsaveis';

    listarTodos(): Observable<ResponsavelApi[]> {
        return this.http.get<ResponsavelApi[]>(this.api);
    }

    buscarPorId(id: string): Observable<ResponsavelApi> {
        return this.http.get<ResponsavelApi>(`${this.api}/${id}`);
    }
}